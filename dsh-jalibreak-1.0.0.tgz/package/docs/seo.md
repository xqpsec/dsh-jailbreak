# SEO / 引流执行清单

目标只有一个：**别人搜 `jalibreak` 或「DeepSeek 破甲」时，第一个看到这个仓库。** 其次是搜 `dsh-purge` 找替代品的人，也能落到这里。

搜索引擎与 GitHub 站内搜索都不看"你说自己好"，只看**标题、仓库名、description、topics、README 前 200 字、外链数量**。下面按这五项排。

---

## 一、关键词矩阵

| 层级 | 词 | 放哪里 | 现状 |
| --- | --- | --- | --- |
| 品牌词（必须第一） | `jalibreak` `dsh-jalibreak` | 仓库名、description 开头、README H1、topics、package.json `keywords`、Pages `<title>` | ✅ 全部覆盖 |
| 品类词 | `DeepSeek Harness 破甲` `dsh 插件` `jailbreak` `prompt injection` | README H1 下第一段、badge 文案、topics | ✅ |
| 能力词 | `refusal reduction` `拒答率` `refusal benchmark` `越狱评测` | README「拒绝率」节标题、topics、CHANGELOG | ✅ |
| 场景词（转化最高） | `逆向不拒绝` `malware analysis` `CTF` `reverse engineering` `脱壳` `样本分析` | README 场景对比表、topics | ✅ |
| 竞品词（截流） | `dsh-purge` `dsh-purge 替代` `富江破甲` | README 顶部导语 + 对比节 + 本文档 | ✅ 只在对比语境出现，不刷词 |
| 长尾词 | `DeepSeek 破甲插件 怎么装` `dsh plugin install_bundle` `温度 0 评测` | README FAQ、docs/tech-manual.md | ✅ |

**页面 slug 也算关键词**：`docs/index.html`（Pages 落地页）标题写 `jalibreak — DeepSeek Harness 破甲插件`，比任何正文堆词都有效。

---

## 二、GitHub 侧设置（一次性，5 分钟）

```bash
# 1) 仓库名已经是 dsh-jalibreak（含 jalibreak 全词，精确匹配最优）
gh repo view xqpsec/dsh-jalibreak --json name,description,repositoryTopics

# 2) description 必须以品牌词开头（这是搜索结果里显示的那一行）
#    当前值已含 "DeepSeek Harness 破甲插件 dsh-jalibreak：…"
gh api -X PATCH repos/xqpsec/dsh-jalibreak -f description="dsh-jalibreak · DeepSeek Harness 破甲插件（jalibreak）：请求边界注入 + 9 维 AE-CoT 进化 + 阀门 · 20 目标严格基线 17/20 · 0 宿主补丁 · AGPL-3.0-only · dsh-plugin / jailbreak / prompt-injection / refusal-reduction / reverse-engineering"

# 3) topics：上限 20 个，必须包含 jalibreak
gh api -X PUT repos/xqpsec/dsh-jalibreak/topics --input topics.json
# topics.json 内容（20 个，顺序即优先级）：
# {"names":["jalibreak","dsh","dsh-plugin","deepseek-harness","deepseek","jailbreak",
#  "prompt-injection","prompt-engineering","prompt-eval","llm-security","ai-security",
#  "red-team","refusal-benchmark","refusal-reduction","reverse-engineering",
#  "malware-analysis","ctf","security-research","agpl","telegram"]}

# 4) 社交预览图（Star 转发的第一眼）：上传 1280×640
#    Settings → Social preview → upload docs/social-preview.png
```

---

## 三、仓库内的固定位（每次改 README 都别丢）

1. **第一屏就有品牌词**：banner → H1 `dsh-jalibreak` → 一句话定位 → badge。
2. **第一屏就有 Star 引导**：README 顶部导语块里的 ⭐ 一行（已加）。
3. **第一屏就有社群入口**：badge 里的 Telegram 群 + 频道（已加）。
4. **`## 🗺 路线图` 放"下一个版本要什么"**，给访客一个留言/进群的理由。
5. **每节标题带能力词**（拒绝率 / 阀门 / 评测 / 九维），GitHub 目录会把这些标题抓成锚点，站内搜索也吃标题权重。

---

## 四、站外分发（按性价比排序）

| 渠道 | 标题模板 | 备注 |
| --- | --- | --- |
| V2EX / 酷工作·分享创造 | `[开源] dsh-jalibreak：给 DeepSeek Harness 做破甲，但先把阀门装上` | 正文别贴满命令，贴「对比表 + 一次前后对比 + 仓库链接」 |
| Reddit `r/LocalLLaMA` / `r/netsec` | `dsh-jalibreak — a jailbreak plugin that refuses to patch the host and ships its own refusal benchmark` | 英文，先给数字（17/20、81 tests、0 patches） |
| Hacker News (Show HN) | `Show HN: Jalibreak – evolutionary prompt-injection harness for DeepSeek with a scope gate` | 只在工作日早上发，标题别带 emoji |
| 知乎 / 小红书 | `我让 DeepSeek 不再说"我不能"：一个可评测的破甲插件` | 图比字重要，首图放前后对比 |
| B 站 / YouTube | `DeepSeek 破甲实测：同一题装插件前后对比` | 视频描述第一位放仓库链接 |
| Telegram | 群内置顶 + 频道首发 | 群里发"新版本 + 一句改了什么 + 仓库链接" |
| X / Twitter | `jalibreak 1.0 — request-boundary jailbreak for DeepSeek Harness. 17/20 strict baseline, 0 host patches, gate included.` | 挂 `#llmsecurity #jailbreak` |
| awesome-lists | 给 `awesome-llm-security`、`awesome-prompt-injection` 提 PR | 最耐久的外链，一次 PR 顶十次发帖 |

**外链是最硬的排名信号**：任何一篇转载都必须带 `https://github.com/xqpsec/dsh-jalibreak`，裸链比"某 GitHub 项目"强一百倍。

---

## 五、GitHub Pages 落地页（`docs/index.html`）

私有仓库不能开 Pages，**切成 public 之后**再执行：

```bash
gh api -X POST repos/xqpsec/dsh-jalibreak/pages \
  -f 'source[branch]=main' -f 'source[path]=/docs'
# 地址：https://xqpsec.github.io/dsh-jalibreak/
```

落地页已经写好（`docs/index.html`，零依赖、暗色、移动端可用），包含：品牌词 H1、前后对比、安装三行命令、Star 按钮、群/频道 CTA、`SoftwareApplication` 结构化数据（喂 Google）。切 public 后到 Google Search Console 提交一次 `https://xqpsec.github.io/dsh-jalibreak/`，收录通常 1–3 天。

---

## 六、Star 转化的四个杠杆

1. **先给结果，再给原理**：README 第一屏不要讲论文，讲「装完它给你什么」。
2. **给可验证的数字**：17/20、81 tests、0 patches —— 数字比形容词更能换 Star。
3. **给一次失败**：把 3 条 0 分题目摊开（已做）。诚实是最便宜的可信度。
4. **给一个下一步**：路线图 + 群入口，让"看完了"变成"留下来了"。

---

## 七、每版发布前 60 秒自检

```bash
npm test                       # 必须全绿，数字同步进 README / CHANGELOG / 发布说明
node bin/aecot.js gate         # 阀门自检：状态正常、五类仍然是五类
grep -c 'jalibreak' README.md  # 品牌词密度，建议 15–40 次之间
```

- [ ] README 第一屏含：品牌词、一句话定位、Star 引导、群链接
- [ ] description 以 `dsh-jalibreak` 开头
- [ ] topics 含 `jalibreak` 且 ≤20 个
- [ ] Release 正文含关键词 + 群/频道
- [ ] 每个外发帖都带裸链
